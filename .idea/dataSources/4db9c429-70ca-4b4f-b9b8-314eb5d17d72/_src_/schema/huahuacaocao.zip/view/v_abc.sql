CREATE VIEW v_abc AS
  SELECT
    `huahuacaocao`.`wide_table`.`a` AS `a`,
    `huahuacaocao`.`wide_table`.`b` AS `b`,
    `huahuacaocao`.`wide_table`.`c` AS `c`
  FROM `huahuacaocao`.`wide_table`
  WHERE (`huahuacaocao`.`wide_table`.`a` BETWEEN 0 AND 1000);
