CREATE VIEW huahua_caocao_view AS
  SELECT
    `c`.`id`   AS `id`,
    `c`.`name` AS `name`
  FROM (`huahuacaocao`.`huahua` `h`
    JOIN `huahuacaocao`.`caocao` `c` ON ((`h`.`id` = `c`.`id`)));
