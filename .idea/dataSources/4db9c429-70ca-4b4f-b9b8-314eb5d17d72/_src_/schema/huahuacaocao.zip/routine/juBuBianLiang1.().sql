CREATE PROCEDURE juBuBianLiang1(OUT number1 INT)
  BEGIN
	#Routine body goes here...
DECLARE number2 INTEGER
DEFAULT (SELECT COUNT(*) FROM huahua);
SET number1=number2;
END;
