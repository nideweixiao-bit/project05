CREATE PROCEDURE huahua_id(IN huahuaid INT)
  BEGIN 
SELECT *
FROM huahua
WHERE id=huahuaid;
END;
