CREATE PROCEDURE SELECT_id(IN select_id INT)
  BEGIN 
 SELECT *
FROM huahua
WHERE id=select_id;
END;
